#ifndef tree_h
#define tree_h

struct treeNode
{
    int data;
    struct treeNode* left;
    struct treeNode* right;
};

struct treeNode* createNode(int data);

int findHeight(struct treeNode* root);

#endif