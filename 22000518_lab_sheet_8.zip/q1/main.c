#include<stdio.h>
#include "function.h"

int main() {
    struct treeNode* root = createNode(1);
    root->left = createNode(2);
    root->right = createNode(3);
    root->left->left = createNode(4);
    root->left->right = createNode(5);

    int height = findHeight(root);
    printf("Height of the binary tree: %d\n", height);

    return 0;
}