#include "function.h"
#include<stdlib.h>

struct treeNode* createNode(int data) {
    struct treeNode* newNode = (struct treeNode*)malloc(sizeof(struct treeNode));
    newNode->data = data;
    newNode->left = newNode->right = NULL;
    return newNode;
}


int findHeight(struct treeNode* root) {
    if (root == NULL) {
        return 0;
    } else {
        int leftHeight = findHeight(root->left);
        int rightHeight = findHeight(root->right);

        return (leftHeight > rightHeight) ? (leftHeight + 1) : (rightHeight + 1);
    }
}