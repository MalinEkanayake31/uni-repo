#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include "function.h"

int nodeHeight(struct AVLNode* node) {
    if (node == NULL)
        return 0;
    return node->height;
}

int balanceFactor(struct AVLNode* node) {
    if (node == NULL)
        return 0;
    return nodeHeight(node->left) - nodeHeight(node->right);
}

struct AVLNode* createNode(int data) {
    struct AVLNode* newNode = (struct AVLNode*)malloc(sizeof(struct AVLNode));
    newNode->data = data;
    newNode->left = newNode->right = NULL;
    newNode->height = 1; 
    return newNode;
}

struct AVLNode* rightRotate(struct AVLNode* y) {
    struct AVLNode* x = y->left;
    struct AVLNode* T2 = x->right;

    x->right = y;
    y->left = T2;

    y->height = 1 + fmax(nodeHeight(y->left), nodeHeight(y->right));
    x->height = 1 + fmax(nodeHeight(x->left), nodeHeight(x->right));

    return x;
}

struct AVLNode* leftRotate(struct AVLNode* x) {
    struct AVLNode* y = x->right;
    struct AVLNode* T2 = y->left;

    y->left = x;
    x->right = T2;

    x->height = 1 + fmax(nodeHeight(x->left), nodeHeight(x->right));
    y->height = 1 + fmax(nodeHeight(y->left), nodeHeight(y->right));

    return y;
}

struct AVLNode* insertNode(struct AVLNode* root, int data) {
   
    if (root == NULL)
        return createNode(data);

    if (data < root->data)
        root->left = insertNode(root->left, data);
    else if (data > root->data)
        root->right = insertNode(root->right, data);
    else
        return root; 
   
    root->height = 1 + fmax(nodeHeight(root->left), nodeHeight(root->right));

    int balance = balanceFactor(root);

    if (balance > 1 && data < root->left->data)
        return rightRotate(root);

    if (balance < -1 && data > root->right->data)
        return leftRotate(root);

    if (balance > 1 && data > root->left->data) {
        root->left = leftRotate(root->left);
        return rightRotate(root);
    }

    if (balance < -1 && data < root->right->data) {
        root->right = rightRotate(root->right);
        return leftRotate(root);
    }

    return root;
}

void inorderTraversal(struct AVLNode* root) {
    if (root != NULL) {
        inorderTraversal(root->left);
        printf("%d ", root->data);
        inorderTraversal(root->right);
    }
}

void preorderTraversal(struct AVLNode* root) {
    if (root != NULL) {
        printf("%d ", root->data);
        preorderTraversal(root->left);
        preorderTraversal(root->right);
    }
}

void postorderTraversal(struct AVLNode* root) {
    if (root != NULL) {
        postorderTraversal(root->left);
        postorderTraversal(root->right);
        printf("%d ", root->data);
    }
}

void freeAVLTree(struct AVLNode* root) {
    if (root != NULL) {
        freeAVLTree(root->left);
        freeAVLTree(root->right);
        free(root);
    }
}