#ifndef tree_h
#define tree_h

struct AVLNode
{
    int data;
    struct AVLNode* left;
    struct AVLNode* right;
    int height; 
};

struct AVLNode* createNode(int data);

int nodeHeight(struct AVLNode* node);

int balanceFactor(struct AVLNode* node);

struct AVLNode* rightRotate(struct AVLNode* y);

struct AVLNode* leftRotate(struct AVLNode* x);

struct AVLNode* insertNode(struct AVLNode* root, int data);

void inorderTraversal(struct AVLNode* root);

void preorderTraversal(struct AVLNode* root);

void postorderTraversal(struct AVLNode* root);

void freeAVLTree(struct AVLNode* root);

#endif