#include<stdlib.h>
#include<stdio.h>
#include "function.h"

struct TreeNode* createNode(int data) {
    struct TreeNode* newNode = (struct TreeNode*)malloc(sizeof(struct TreeNode));
    newNode->data = data;
    newNode->left = newNode->right = NULL;
    return newNode;
}

int findHeight(struct TreeNode* root) {
    if (root == NULL) {
        return 0;
    } else {
    
        int leftHeight = findHeight(root->left);
        int rightHeight = findHeight(root->right);

        return (leftHeight > rightHeight) ? (leftHeight + 1) : (rightHeight + 1);
    }
}

void printNodeDepths(struct TreeNode* root, int depth) {
    if (root != NULL) {
        printf("Node with data %d has depth %d\n", root->data, depth);
        printNodeDepths(root->left, depth + 1);
        printNodeDepths(root->right, depth + 1);
    }
}

void printNodeDOF(struct TreeNode* root) {
    if (root != NULL) {
        int degreeOfFreedom = 0;
        if (root->left != NULL) degreeOfFreedom++;
        if (root->right != NULL) degreeOfFreedom++;

        printf("Node with data %d has degree of freedom %d\n", root->data, degreeOfFreedom);

        printNodeDOF(root->left);
        printNodeDOF(root->right);
    }
}
