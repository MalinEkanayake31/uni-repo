#ifndef BINARY_TREE_H
#define BINARY_TREE_H

struct TreeNode {
    int data;
    struct TreeNode* left;
    struct TreeNode* right;
};

struct TreeNode* createNode(int data);

int findHeight(struct TreeNode* root);

void printNodeDepths(struct TreeNode* root, int depth);

void printNodeDOF(struct TreeNode* root);

#endif 