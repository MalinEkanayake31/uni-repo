#include<stdio.h>
#include "function.h"

int main() {
    struct TreeNode* root = createNode(1);
    root->left = createNode(2);
    root->right = createNode(3);
    root->left->left = createNode(4);
    root->left->right = createNode(5);
    root->right->left = createNode(6);
    root->right->right = createNode(7);

    int height = findHeight(root);
    printf("Height of the binary tree: %d\n", height);

    printf("\nDepth of each node:\n");
    printNodeDepths(root, 0);

    printf("\nDegree of freedom for each node:\n");
    printNodeDOF(root);

    return 0;
}