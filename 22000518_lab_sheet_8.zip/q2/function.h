#ifndef BINARY_TREE_H
#define BINARY_TREE_H

struct TreeNode {
    int data;
    struct TreeNode* left;
    struct TreeNode* right;
};

struct TreeNode* createNode(int data);

int findHeight(struct TreeNode* root);

int isBalanced(struct TreeNode* root);

#endif 
