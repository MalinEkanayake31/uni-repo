#include "function.h"
#include<stdlib.h>

struct TreeNode* createNode(int data) {
    struct TreeNode* newNode = (struct TreeNode*)malloc(sizeof(struct TreeNode));
    newNode->data = data;
    newNode->left = newNode->right = NULL;
    return newNode;
}

int findHeight(struct TreeNode* root) {

    if (root == NULL) {
        return 0;
    } else {
        int leftHeight = findHeight(root->left);
        int rightHeight = findHeight(root->right);

        return (leftHeight > rightHeight) ? (leftHeight + 1) : (rightHeight + 1);
    }
}

int isBalanced(struct TreeNode* root) {
    if (root == NULL) {
        return 1;
    }

    int leftHeight = findHeight(root->left);
    int rightHeight = findHeight(root->right);

    if (abs(leftHeight - rightHeight) <= 1 &&
        isBalanced(root->left) &&
        isBalanced(root->right)) {
        return 1; 
    }

    return 0; 
}

