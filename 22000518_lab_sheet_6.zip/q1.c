#include <stdio.h>
#include <stdbool.h>

#define MAX_VERTICES 8  // Adjust this if needed based on the graph's size

bool visited[MAX_VERTICES] = {false};  // Array to track visited vertices

// Function to add edges to the graph (replace with actual adjacency list representation if needed)
void addEdge(int graph[][MAX_VERTICES], int u, int v) {
   graph[u][v] = 1;
   graph[v][u] = 1;  // Assuming undirected graph
}

// Function to perform BFS traversal
void BFS(int graph[][MAX_VERTICES], int startVertex) {
   int queue[MAX_VERTICES], front = -1, rear = -1;

   // Enqueue the starting vertex
   queue[++rear] = startVertex;
   visited[startVertex] = true;

   // BFS loop
   while (front != rear) {
       // Dequeue a vertex from the queue and print it
       int vertex = queue[++front];
       printf("%c ", vertex + 'A');

       // Enqueue all unvisited adjacent vertices
       for (int i = 0; i < MAX_VERTICES; i++) {
           if (graph[vertex][i] == 1 && !visited[i]) {
               queue[++rear] = i;
               visited[i] = true;
           }
       }
   }
}

int main() {
   int graph[MAX_VERTICES][MAX_VERTICES] = {0};

   // Create the graph based on the given diagram
   addEdge(graph, 0, 1);  // A-B
   addEdge(graph, 0, 2);  // A-C
   addEdge(graph, 1, 3);  // B-D
   addEdge(graph, 1, 4);  // B-E
   addEdge(graph, 2, 5);  // C-F
   addEdge(graph, 2, 6);  // C-G
   addEdge(graph, 3, 7);  // D-H

   printf("BFS traversal: ");
   BFS(graph, 0);  // Start BFS from vertex A (index 0)

   return 0;
}