#include <stdio.h>
#include <stdlib.h>

struct TreeNode
{
    int data;
    struct TreeNode *left;
    struct TreeNode *right;
};

struct TreeNode *createNode(int data)
{
    struct TreeNode *newNode = (struct TreeNode *)malloc(sizeof(struct TreeNode));
    newNode->data = data;
    newNode->left = NULL;
    newNode->right = NULL;
    return newNode;
}

struct TreeNode *insertNode(struct TreeNode *root, int data)
{
    if (root == NULL)
    {
        return createNode(data);
    }
    else
    {
        if (data <= root->data)
        {
            root->left = insertNode(root->left, data);
        }
        else
        {
            root->right = insertNode(root->right, data);
        }
        return root;
    }
}

void recursivePreorder(struct TreeNode *root)
{
    if (root != NULL)
    {
        printf("%d ", root->data);
        recursivePreorder(root->left);
        recursivePreorder(root->right);
    }
}

void recursiveInorder(struct TreeNode *root)
{
    if (root != NULL)
    {
        recursiveInorder(root->left);
        printf("%d ", root->data);
        recursiveInorder(root->right);
    }
}

void recursivePostorder(struct TreeNode *root)
{
    if (root != NULL)
    {
        recursivePostorder(root->left);
        recursivePostorder(root->right);
        printf("%d ", root->data);
    }
}

void freeTree(struct TreeNode *root)
{
    if (root != NULL)
    {
        freeTree(root->left);
        freeTree(root->right);
        free(root);
    }
}

int main()
{
    struct TreeNode *root = NULL;
    int choice, data;

    do
    {
        printf("\n1. Insert Node\n");
        printf("2. Recursive Pre-order Traversal\n");
        printf("3. Recursive In-order Traversal\n");
        printf("4. Recursive Post-order Traversal\n");
        printf("5. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice)
        {
        case 1:
            printf("Enter data to insert: ");
            scanf("%d", &data);
            root = insertNode(root, data);
            break;
        case 2:
            printf("Recursive Pre-order Traversal: ");
            recursivePreorder(root);
            printf("\n");
            break;
        case 3:
            printf("Recursive In-order Traversal: ");
            recursiveInorder(root);
            printf("\n");
            break;
        case 4:
            printf("Recursive Post-order Traversal: ");
            recursivePostorder(root);
            printf("\n");
            break;
        case 5:
            freeTree(root);
            printf("Exiting the program.\n");
            break;
        default:
            printf("Invalid choice. Try again.\n");
        }
    } while (choice != 5);

    return 0;
}
