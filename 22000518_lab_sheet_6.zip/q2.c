#include <stdio.h>
#include <stdlib.h>

struct TreeNode
{
int data;
struct TreeNode *left;
struct TreeNode *right;
};

struct TreeNode *createNode(int data)
{
struct TreeNode *newNode = (struct TreeNode *)malloc(sizeof(struct TreeNode));
newNode->data = data;
newNode->left = NULL;
newNode->right = NULL;
return newNode;
}

void recursivePreorder(struct TreeNode *root)
{
if (root != NULL)
{
    printf("%d ", root->data);
    recursivePreorder(root->left);
    recursivePreorder(root->right);
}
}

void recursiveInorder(struct TreeNode *root)
{
if (root != NULL)
{
    recursiveInorder(root->left);
    printf("%d ", root->data);
    recursiveInorder(root->right);
}
}

void recursivePostorder(struct TreeNode *root)
{
if (root != NULL)
{
    recursivePostorder(root->left);
    recursivePostorder(root->right);
    printf("%d ", root->data);
}
}

void iterativePreorder(struct TreeNode *root)
{
if (root == NULL)
    return;

struct TreeNode *stack[100];
int top = -1;

stack[++top] = root;

while (top >= 0)
{
    struct TreeNode *current = stack[top--];
    printf("%d ", current->data);

    if (current->right != NULL)
        stack[++top] = current->right;

    if (current->left != NULL)
        stack[++top] = current->left;
}
}

void iterativeInorder(struct TreeNode *root)
{
if (root == NULL)
    return;

struct TreeNode *stack[100];
int top = -1;
struct TreeNode *current = root;

while (current != NULL || top >= 0)
{
    while (current != NULL)
    {
        stack[++top] = current;
        current = current->left;
    }

    current = stack[top--];
    printf("%d ", current->data);
    current = current->right;
}
}

void iterativePostorder(struct TreeNode *root)
{
if (root == NULL)
    return;

struct TreeNode *stack1[100];
struct TreeNode *stack2[100];
int top1 = -1;
int top2 = -1;

stack1[++top1] = root;

while (top1 >= 0)
{
    struct TreeNode *current = stack1[top1--];
    stack2[++top2] = current;

    if (current->left != NULL)
        stack1[++top1] = current->left;
    if (current->right != NULL)
        stack1[++top1] = current->right;
}

while (top2 >= 0)
{
    printf("%d ", stack2[top2--]->data);
}
}

void freeTree(struct TreeNode *root)
{
if (root != NULL)
{
    freeTree(root->left);
    freeTree(root->right);
    free(root);
}
}

int main()
{
struct TreeNode *root = NULL;
int choice, data;

do
{
    printf("\n1. Insert Node\n");
    printf("2. Recursive Pre-order Traversal\n");
    printf("3. Recursive In-order Traversal\n");
    printf("4. Recursive Post-order Traversal\n");
    printf("5. Iterative Pre-order Traversal\n");
    printf("6. Iterative In-order Traversal\n");
    printf("7. Iterative Post-order Traversal\n");
    printf("8. Exit\n");
    printf("Enter your choice: ");
    scanf("%d", &choice);

    switch (choice)
    {
    case 1:
        printf("Enter data to insert: ");
        scanf("%d", &data);
        if (root == NULL)
        {
            root = createNode(data);
        }
        else
        {
            struct TreeNode *temp = root;
            while (1)
            {
                printf("Insert as left child (1) or right child (2) of %d? ", temp->data);
                int position;
                scanf("%d", &position);
                if (position == 1)
                {
                    if (temp->left == NULL)
                    {
                        temp->left = createNode(data);
                        break;
                    }
                    else
                    {
                        temp = temp->left;
                    }
                }
                else if (position == 2)
                {
                    if (temp->right == NULL)
                    {
                        temp->right = createNode(data);
                        break;
                    }
                    else
                    {
                        temp = temp->right;
                    }
                }
                else
                {
                    printf("Invalid choice. Try again.\n");
                }
            }
        }
        break;
    case 2:
        printf("Recursive Pre-order Traversal: ");
        recursivePreorder(root);
        printf("\n");
        break;
    case 3:
        printf("Recursive In-order Traversal: ");
        recursiveInorder(root);
        printf("\n");
        break;
    case 4:
        printf("Recursive Post-order Traversal: ");
        recursivePostorder(root);
        printf("\n");
        break;
    case 5:
        printf("Iterative Pre-order Traversal: ");
        iterativePreorder(root);
        printf("\n");
        break;
    case 6:
        printf("Iterative In-order Traversal: ");
        iterativeInorder(root);
        printf("\n");
        break;
    case 7:
        printf("Iterative Post-order Traversal: ");
        iterativePostorder(root);
        printf("\n");
        break;
    case 8:
        freeTree(root);
        printf("Exiting the program.\n");
        break;
    default:
        printf("Invalid choice. Try again.\n");
    }
} while (choice != 8);

return 0;
}