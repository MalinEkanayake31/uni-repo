#include<stdio.h>

int main(){
    printf("Size of void pointer is: %zu bytes\n", sizeof(void*));
    return 0;
}