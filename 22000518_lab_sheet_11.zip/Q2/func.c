#include "header.h"

struct BookNode* createBookNode(long long isbn, const char *title) 
{
    struct BookNode* newNode = (struct BookNode*)malloc(sizeof(struct BookNode));
    newNode->isbn = isbn;
    
    strcpy(newNode->title, title);
    newNode->color = RED;
    newNode->left = NULL;
    newNode->right = NULL;
    newNode->parent = NULL;
    return newNode;
}

void leftRotate(struct BookNode **root, struct BookNode *x) 
{
    struct BookNode *y = x->right;

    x->right = y->left;

    if (y->left != NULL)
        y->left->parent = x;

    y->parent = x->parent;
    if (x->parent == NULL)
        *root = y;

    else if (x == x->parent->left)
        x->parent->left = y;

    else
        x->parent->right = y;

    y->left = x;
    x->parent = y;
}

void rightRotate(struct BookNode **root, struct BookNode *y) 
{
    struct BookNode *x = y->left;
    y->left = x->right;

    if (x->right != NULL)
        x->right->parent = y;

    x->parent = y->parent;

    if (y->parent == NULL)
        *root = x;

    else if (y == y->parent->left)
        y->parent->left = x;

    else
        y->parent->right = x;

    x->right = y;
    y->parent = x;
}

void fixViolation(struct BookNode **root, struct BookNode *z) 
{
    while (z != *root && z->parent->color == RED) 
    {
        if (z->parent == z->parent->parent->left) 
        {
            struct BookNode *y = z->parent->parent->right;
            if (y != NULL && y->color == RED) 
            {
                z->parent->color = BLACK;
                y->color = BLACK;
                z->parent->parent->color = RED;
                z = z->parent->parent;
            } 
            else 
            {
                if (z == z->parent->right) 
                {
                    z = z->parent;
                    leftRotate(root, z);
                }

                z->parent->color = BLACK;
                z->parent->parent->color = RED;

                rightRotate(root, z->parent->parent);
            }
        } 
        else 
        {
            struct BookNode *y = z->parent->parent->left;

            if (y != NULL && y->color == RED) 
            {
                z->parent->color = BLACK;
                y->color = BLACK;
                z->parent->parent->color = RED;
                z = z->parent->parent;
            } 
            else 
            {
                if (z == z->parent->left) 
                {
                    z = z->parent;
                    rightRotate(root, z);
                }

                z->parent->color = BLACK;
                z->parent->parent->color = RED;

                leftRotate(root, z->parent->parent);
            }
        }
    }

    (*root)->color = BLACK;
}

void insertBook(struct BookNode **root, long long isbn, const char *title) 
{
    if (searchISBN(*root, isbn)) 
    {
        printf("Error: Book with ISBN %lld already exists in the inventory.\n", isbn);

        return;
    }

    struct BookNode *z = createBookNode(isbn, title);
    struct BookNode *y = NULL;
    struct BookNode *x = *root;

    while (x != NULL) 
    {
        y = x;
        if (z->isbn < x->isbn)
            x = x->left;
        else
            x = x->right;
    }

    z->parent = y;

    if (y == NULL)
        *root = z;
    else if (z->isbn < y->isbn)
        y->left = z;
    else
        y->right = z;

    fixViolation(root, z);
}

bool searchISBN(struct BookNode *root, long long isbn) 
{
    if (root == NULL)
        return false;
    if (root->isbn == isbn)
        return true;
    if (isbn < root->isbn)
        return searchISBN(root->left, isbn);
    else
        return searchISBN(root->right, isbn);
}

void printInventory(struct BookNode *root, int space) 
{
    if (root == NULL)
        return;

    space += 5;

    printInventory(root->right, space);

    printf("\n");

    for (int i = 5; i < space; i++)
        printf(" ");

    printf("%lld - %s(%c)\n", root->isbn, root->title, root->color == RED ? 'R' : 'B');
    printInventory(root->left, space);
}