#include "header.h"

int main() 
{
    struct BookNode *root = NULL;

    insertBook(&root, 9783161484100, "1984 by George Orwell");
    printf("Inventory after inserting 1984 by George Orwell:\n");
    printInventory(root, 0);

    insertBook(&root, 9780451524935, "To Kill a Mockingbird by Harper Lee");
    printf("\nInventory after inserting To Kill a Mockingbird by Harper Lee:\n");
    printInventory(root, 0);

    insertBook(&root, 9780743273565, "The Great Gatsby by F. Scott Fitzgerald");
    printf("\nInventory after inserting The Great Gatsby by F. Scott Fitzgerald:\n");
    printInventory(root, 0);

    insertBook(&root, 9780061120084, "Lord of the Flies by William Golding");
    printf("\nInventory after inserting Lord of the Flies by William Golding:\n");
    printInventory(root, 0);

    insertBook(&root, 9783161484100, "1984 by George Orwell");

    return 0;
}
