#ifndef HEADER_H
#define HEADER_H

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

#define RED 0
#define BLACK 1

struct BookNode 
{
    long long isbn;
    char title[100];
    int color;
    struct BookNode *parent;
    struct BookNode *left;
    struct BookNode *right;
};

struct BookNode* createBookNode(long long isbn, const char *title);
void leftRotate(struct BookNode **root, struct BookNode *x);
void rightRotate(struct BookNode **root, struct BookNode *x);
void fixViolation(struct BookNode **root, struct BookNode *z);
void insertBook(struct BookNode **root, long long isbn, const char *title);
void insertFixup(struct BookNode **root, struct BookNode *z);
void printInventory(struct BookNode *root, int space);
bool searchISBN(struct BookNode *root, long long isbn);

#endif