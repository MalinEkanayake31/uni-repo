#ifndef HEADER_H
#define HEADER_H

#include <stdio.h>
#include <stdlib.h>

#define RED 0
#define BLACK 1

struct Node 
{
    int key;
    int color;
    struct Node *parent;
    struct Node *left;
    struct Node *right;
};

struct Node* createNode(int key);
void leftRotate(struct Node **root, struct Node *x);
void rightRotate(struct Node **root, struct Node *x);
void fixViolation(struct Node **root, struct Node *z);
void insert(struct Node **root, int key);
void insertFixup(struct Node **root, struct Node *z);
void printTree(struct Node *root, int space);

#endif