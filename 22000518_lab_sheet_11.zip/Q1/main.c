#include "header.h"

int main() 
{
    struct Node *root = NULL;

    insert(&root, 10);
    printf("Tree after inserting 10:\n");
    printTree(root, 0);

    insert(&root, 20);
    printf("\nTree after inserting 20:\n");
    printTree(root, 0);

    insert(&root, 30);
    printf("\nTree after inserting 30:\n");
    printTree(root, 0);

    insert(&root, 15);
    printf("\nTree after inserting 15:\n");
    printTree(root, 0);

    insert(&root, 25);
    printf("\nTree after inserting 25:\n");
    printTree(root, 0);

    insert(&root, 5);
    printf("\nTree after inserting 5:\n");
    printTree(root, 0);

    return 0;
}
